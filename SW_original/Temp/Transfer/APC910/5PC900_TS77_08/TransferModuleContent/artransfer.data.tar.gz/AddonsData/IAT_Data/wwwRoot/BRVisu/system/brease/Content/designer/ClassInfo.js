/*global define*/
define(function (require) {
    'use strict';
    return {
        meta: {
            className: "system.brease.Content",
            parents: [],
            children: ["*"],
            inheritance: []
        }
    };
});