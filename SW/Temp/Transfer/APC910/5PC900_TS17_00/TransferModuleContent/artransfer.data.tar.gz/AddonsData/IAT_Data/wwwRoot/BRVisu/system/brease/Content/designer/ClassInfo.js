define(function () {
    'use strict';
    return {
        meta: {
            className: 'system.brease.Content',
            parents: [],
            children: ['*'],
            inheritance: []
        }
    };
});
